from flask import Flask, request, jsonify
from pymongo import MongoClient
import gridfs
from flask_cors import CORS
from datetime import datetime

app = Flask(__name__)

# Enable CORS for all domains
CORS(app)

# MongoDB Configuration
MONGO_URI = "mongodb://localhost:27017"
client = MongoClient(MONGO_URI)
db = client["file_storage_db"]  # Database name
fs = gridfs.GridFS(db)  # GridFS for file storage
metadata_collection = db["file_metadata"]  # Collection for file metadata

# Upload File Endpoint
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file part in the request"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400

    # Store the file in GridFS
    file_id = fs.put(file, filename=file.filename)

    # Store file metadata in a separate collection
    metadata = {
        "file_id": str(file_id),
        "filename": file.filename,
        "content_type": file.content_type,
        "modified": False,  # Track if the file has been modified
        "shared": False,  # Track if the file is shared
        "last_modified": datetime.utcnow(),  # Track the last modified timestamp
    }
    metadata_collection.insert_one(metadata)

    return jsonify({"file_id": str(file_id), "message": "File uploaded successfully!"}), 200

# View File Metadata Endpoint
@app.route('/files', methods=['GET'])
def list_files():
    files = metadata_collection.find()
    result = []
    for file in files:
        result.append({
            "file_id": file["file_id"],
            "filename": file["filename"],
            "content_type": file["content_type"],
            "modified": file["modified"],
            "shared": file["shared"],
            "last_modified": file["last_modified"]
        })
    return jsonify(result), 200

# Update File Metadata (e.g., modified or shared)
@app.route('/update/<file_id>', methods=['PUT'])
def update_file_metadata(file_id):
    update_data = request.get_json()

    modified = update_data.get("modified")
    shared = update_data.get("shared")

    if modified is None and shared is None:
        return jsonify({"error": "No metadata to update"}), 400

    # Update the metadata in MongoDB
    update_fields = {}
    if modified is not None:
        update_fields["modified"] = modified
        update_fields["last_modified"] = datetime.utcnow()  # Update the last modified timestamp

    if shared is not None:
        update_fields["shared"] = shared

    metadata_collection.update_one(
        {"file_id": file_id},
        {"$set": update_fields}
    )

    return jsonify({"message": f"Metadata for file {file_id} updated successfully!"}), 200

# Delete File by Meta ID Endpoint
@app.route('/delete/<file_id>', methods=['DELETE'])
def delete_file(file_id):
    try:
        # Delete file from GridFS
        fs.delete(file_id)
        # Remove metadata from the collection
        metadata_collection.delete_one({"file_id": file_id})
        return jsonify({"message": f"File with ID {file_id} deleted successfully!"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
