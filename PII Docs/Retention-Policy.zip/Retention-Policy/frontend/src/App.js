import React, { useState } from "react";
import axios from "axios";
import './App.css';

const App = () => {
  const [selectedFile, setSelectedFile] = useState(null); // To hold the selected file
  const [fileMetaData, setFileMetaData] = useState([]); // To store metadata of uploaded files
  const [deleteFileId, setDeleteFileId] = useState(""); // Input field for manual deletion by file ID

  // Handle file selection
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
      console.log("File selected:", file.name);
    }
  };

  // Upload the selected file to the server
  const handleUpload = async () => {
    if (!selectedFile) {
      alert("Please select a file before uploading.");
      return;
    }

    const formData = new FormData();
    formData.append("file", selectedFile);

    try {
      const response = await axios.post("http://127.0.0.1:5000/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      alert(`File uploaded successfully! File ID: ${response.data.file_id}`);
      fetchFileMetaData(); // Refresh metadata list after file upload
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("Failed to upload file.");
    }
  };

  // Fetch file metadata
  const fetchFileMetaData = async () => {
    try {
      const response = await axios.get("http://127.0.0.1:5000/files");
      setFileMetaData(response.data); // Store all metadata in the state
    } catch (error) {
      console.error("Error fetching file metadata:", error);
    }
  };

  // Delete file by ID
  const handleDeleteFile = async () => {
    if (!deleteFileId) {
      alert("Please enter a file ID to delete.");
      return;
    }

    try {
      const response = await axios.delete(`http://127.0.0.1:5000/delete/${deleteFileId}`);
      alert(response.data.message);
      fetchFileMetaData(); // Refresh metadata list after deletion
    } catch (error) {
      console.error("Error deleting file:", error);
      alert("Failed to delete file.");
    }
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial, sans-serif" }}>
      <h2>File Upload System</h2>

      {/* File Upload Section */}
      <div style={{ marginBottom: "20px" }}>
        <label htmlFor="fileInput" style={{ marginRight: "10px" }}>Choose File:</label>
        <input
          id="fileInput"
          type="file"
          onChange={handleFileChange}
          style={{ marginRight: "10px" }}
        />
        <button onClick={handleUpload}>Upload File</button>
      </div>

      {/* Metadata Display Section */}
      <div>
        <h3>Uploaded Files Metadata</h3>
        <button onClick={fetchFileMetaData} style={{ marginBottom: "10px" }}>
          Refresh File List
        </button>
        <ul>
          {fileMetaData.length === 0 ? (
            <li>No files uploaded yet.</li>
          ) : (
            fileMetaData.map((file) => (
              <li key={file.file_id}>
                <strong>ID:</strong> {file.file_id}, <strong>Filename:</strong> {file.filename}, <strong>Type:</strong> {file.content_type}, <strong>Modified:</strong> {file.modified ? "Yes" : "No"}, <strong>Shared:</strong> {file.shared ? "Yes" : "No"}, <strong>Last Modified:</strong> {new Date(file.last_modified).toLocaleString()}
              </li>
            ))
          )}
        </ul>
      </div>

      {/* File Deletion Section */}
      <div style={{ marginTop: "20px" }}>
        <h3>Delete File</h3>
        <input
          type="text"
          placeholder="Enter file ID to delete"
          value={deleteFileId}
          onChange={(e) => setDeleteFileId(e.target.value)}
          style={{ marginRight: "10px" }}
        />
        <button onClick={handleDeleteFile}>Delete File</button>
      </div>
    </div>
  );
};

export default App;
