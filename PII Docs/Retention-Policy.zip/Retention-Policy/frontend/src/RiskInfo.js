import React from 'react'

const RiskInfo = () => {
  return (
    <div>RiskInfo</div>
  )
}

export default RiskInfo