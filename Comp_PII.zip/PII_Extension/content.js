document.addEventListener("change", (event) => {
    if (event.target && event.target.type === "file") {
      console.log("File input detected:", event.target);
  
      const files = event.target.files;
      if (files.length > 0) {
        for (const file of files) {
          console.log("File selected:", file.name, file.type, file.size);
  
          // Use FileReader to read the file
          const reader = new FileReader();
          reader.onload = () => {
            console.log("File read successfully:", file.name);
  
            // Send file data to the background script
            chrome.runtime.sendMessage(
              {
                action: "uploadFile",
                fileName: file.name,
                fileType: file.type,
                fileData: reader.result, // Send file as a base64 string
              },
              (response) => {
                console.log("Response from background.js:", response);
  
                // Check if PII is detected in the response
                if (response.data.pii_detected === 1) {
                  // Show a custom dialog box with options
                  const userChoice = confirm(
                    "Warning: Personally Identifiable Information detected in the uploaded file. Do you want to continue or inspect?"
                  );
  
                  // Redirect based on user's choice
                  if (userChoice) {
                    // "Continue" option: Do nothing (continue with the upload or action)
                    console.log("User chose to continue.");
                  } else {
                    // "Inspect" option: Redirect to another page
                    const newWindow = window.open('http://localhost:3000/inspect', '_blank');

                    newWindow.onload = () => {
                    // Delay sending the message to ensure the React useEffect has mounted
                    //console.log(response.data.pii_list);
                    console.log(response.data.file_path);
                    setTimeout(() => {
                        newWindow.postMessage(
                        {
                            piiData: response.data.pii_list,
                            filePath: response.data.file_path,
                        },
                    '*'
                    );
                     }, 500); // 500ms delay to ensure useEffect has set up the listener
                    };
                  }
                }
              }
            );
          };
  
          reader.readAsDataURL(file); // Read file as a Base64 URL
        }
      }
    }
  });
  